import random
from Perceptron import Perceptron

num_train = 100
num_valid = 100
#Create Perceptions for the AND , OR and NOT gates
AND = Perceptron(2, bias=-1.0)
OR = Perceptron(2, bias=-1.0, seeded_weights=[1,1])
NOT = Perceptron(1, bias=1.0)
#This function generates training examples for the different gates as well as their corresponding lables. It then trains this examples until all points are correctly classified
def prediction_examples(gate,GATE,num):
    print("Training GATE_"+str(num)+ "-"" "+ str(gate) + "Gate")
    training_examples = []
    training_labels = []
    for i in range(num_train):
        if gate == "AND":
            training_examples.append([random.random(), random.random()])
            training_labels.append(1.0 if training_examples[i][0] > 0.75 and training_examples[i][1] > 0.75 else 0.0)
        if gate == "OR":
            training_examples.append([1.0 if random.random() > 0.75 else 0.0, 1.0 if random.random() > 0.75 else 0.0])
            training_labels.append(1.0 if training_examples[i][0] > 0.75 or training_examples[i][1] > 0.75 else 0.0)
        if gate == "NOT":
            training_examples.append([random.random(), random.random()])
            training_labels.append(1.0 if training_examples[i][0] < 0.75 else 0.0)
    validate_examples = []
    validate_labels = []
    for i in range(num_valid):
        if gate == "AND":
            validate_examples.append([random.random(), random.random()])
            validate_labels.append(1.0 if validate_examples[i][0] > 0.75 and validate_examples[i][1] > 0.75 else 0.0)
        if gate == "OR":
            validate_examples.append([1.0 if random.random() > 0.75 else 0.0, 1.0 if random.random() > 0.75 else 0.0])
            validate_labels.append(1.0 if validate_examples[i][0] > 0.75 or validate_examples[i][1] > 0.75 else 0.0)
        if gate == "NOT":
            validate_examples.append([random.random(), random.random()])
            validate_labels.append(1.0 if validate_examples[i][0] < 0.75 else 0.0)
    print(GATE.weights)
    valid_percentage = GATE.validate(validate_examples, validate_labels, verbose=True)
    print(valid_percentage)
    i = 0
    #Training algorithm. The while loop keeps iterating indefinitely until all points are correctly classified. It then returns the value of the correctly classified points
    while valid_percentage < 0.98: # We want our Perceptron to have an accuracy of at least 80%
        i += 1
        GATE.train(training_examples, training_labels, 0.2)  # Train our Perceptron
        print('------ Iteration ' + str(i) + ' ------')
        print(GATE.weights)
        valid_percentage = GATE.validate(validate_examples, validate_labels, verbose=True) # Validate it
        print(valid_percentage)

        if i == 1000: 
            break
    return GATE
#The prediction_examples function is called. It creates correctly classified instances of each gate    
Perception_AND = prediction_examples("AND",AND,0)
Perception_OR = prediction_examples("OR",OR,1)
Perception_NOT = prediction_examples("NOT",NOT,2)
#Based on the user input. XOR equation(AB)'(A'B')' is used to classify the point entered by the user
print("Please enter two inputs:")
value = input()
while(value != "exit"):
    X = value.split()
    v1 = 1.0 if float(X[0]) >= 0.75 else 0.0
    v2 = 1.0 if float(X[1]) >= 0.75 else 0.0
    not_v1 = Perception_NOT.predict([v1])
    not_v2 = Perception_NOT.predict([v2])
    x1 = NOT.predict([1.0 if Perception_AND.predict([not_v1,not_v2])else 0.0])
    x2 = NOT.predict([1.0 if Perception_AND.predict([v1,v2])else 0.0])
    print(1.0 if Perception_AND.predict([x1,x2]) else 0.0)
    print("Please enter two inputs:")
    value = input()