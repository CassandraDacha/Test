# CSC3022F ML Assignment 3 ANN

We were tasked to create a  program that implements value iteration and Qlearning

## Files contained in the folder
Classifier.py
XOR.py
Perception.py
Makefile
requirements.txt
report.pdf

## How to compile the program
	make
## How to activate the virtual environment
	source ./venv/bin/activate
##Instal requirements . Sometimes it gives a module error
	pip install -r requirements.txt
## How to run the XOR program
	python XOR.py
##You'll be prompted to enter 2 inputs 
	1 1
## How to run the Classify program
	python Classify.py
##You'll be prompted to enter filepath
	./MNIST/testSample/img_7.jpg"

#NOTE: Test are saved in the test folder

## License
[MIT](https://choosealicense.com/licenses/mit/)
